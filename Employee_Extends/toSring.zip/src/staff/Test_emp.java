package staff;

import utility.Employee;

public class Test_emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*SalesManager sm = new SalesManager(101, "Aarya", 500000.00, 1000.00, 100.00 );
		
		Programmer p = new Programmer(201, "Bhumi", 432525.00, "Library Management", 2, 500.00);
		
		Administrator a = new Administrator(302, "Shruti", 600034.00, 30000.00);*/
		
		/*System.out.println("Sales Manager Details: ");
		sm.display();
		
		System.out.println("Programmer Details: ");
		p.display();
		
		System.out.println("Administration Details: ");
		a.display();*/
		
		Employee [] allemps;
		allemps = new Employee[3];
		allemps[0] = new SalesManager(401, "Aarya", 900000.00, 1000.00, 100.00);
		allemps[1] = new Programmer(601, "Bhumi", 432525.00, "Transport Management", 2, 500.00);
		allemps[2] = new Administrator(902, "Shruti", 600034.00, 30000.00);
		
		//run time polymorphism
		for(int i=0; i<allemps.length; i++ ) {
			allemps[i].display();
			System.out.println("*******************");
		}
		
		/*System.out.println("Sales Manager Details: ");
		System.out.println(sm);
		System.out.println("*******************");
		
		System.out.println("Programmer Details: ");
		System.out.println(p);
		System.out.println("*******************");
		
		System.out.println("Administration Details: ");
		System.out.println(a);
		System.out.println("*******************");*/
	}

}
