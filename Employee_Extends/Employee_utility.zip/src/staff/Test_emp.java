package staff;

import utility.Employee;

public class Test_emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SalesManager sm = new SalesManager(101, "Aarya", 500000.00, 1000.00, 100.00 );
		
		Programmer p = new Programmer(201, "Bhumi", 432525.00, "Library Management", 2, 500.00);
		
		Administrator a = new Administrator(302, "Shruti", 600034.00, 30000.00);
		
		System.out.println("Sales Manager Details: ");
		sm.display();
		
		System.out.println("Programmer Details: ");
		p.display();
		
		System.out.println("Administration Details: ");
		a.display();
	}

}
