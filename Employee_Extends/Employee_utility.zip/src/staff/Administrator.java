package staff;

import utility.Employee;

public class Administrator extends Employee {
	private double allowance;

	public Administrator() {
		// TODO Auto-generated constructor stub
	}

	public Administrator(int id, String name, double salary, double allowance) {
		super(id, name, salary);
		// TODO Auto-generated constructor stub
		this.allowance = allowance;
	}
	
	public void display() {
		super.display();
		System.out.println("Administrator allowance: " + allowance);
	}

}
