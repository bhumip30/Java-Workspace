package staff;

import utility.Employee;

public class SalesManager extends Employee {
	private double salesTarget;
	private double perCommision;
	
	public SalesManager() {
		
	}

	public SalesManager(int id,String name, double salary, double salesTarget, double perCommision) {
		super(id, name, salary);
		this.salesTarget = salesTarget;
		this.perCommision = perCommision;
	}
	
	public void display() {
		super.display();
		System.out.println("Sales Target: " + salesTarget);
		System.out.println("Commision: " + perCommision);
	}

}
