package emp_set;

import java.util.Set;
import java.util.TreeSet;

public class EmployeeMain {

	public static void main(String[] args) {
		Set <Employee> emp = new TreeSet <> ();
		emp.add(new Employee(101, "Aarya", 30000.00f));
		emp.add(new Employee(102, "Dhana", 342400.00f));
		emp.add(new Employee(103, "Kajal", 12340.00f));
		emp.add(new Employee(104, "Bhumi", 90000.00f));
		emp.add(new Employee(105, "Ayush", 56000.00f));
		
		for(Employee e : emp) {
			System.out.println(e);
		}
	}

}
