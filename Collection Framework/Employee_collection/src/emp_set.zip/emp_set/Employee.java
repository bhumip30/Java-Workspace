package emp_set;

public class Employee implements Comparable<Employee> {
	private int id;
	private String name;
	private float salary;
	
	public Employee(int id, String name, float salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee id = " + id +
				" Employee name = " + name + 
				"Employee salary = " + salary ;
	}

	@Override
	public int compareTo(Employee o) {
		int diff = 0;
		diff = (int)(this.salary - o.salary);
		return diff;
	}
	
}
