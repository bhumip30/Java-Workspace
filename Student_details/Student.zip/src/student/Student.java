package student;

import java.io.Serializable;

public class Student extends Person implements Serializable  {
	private int PRN;
	private String cource_name;
	transient int age;
	
	public Student() {
		super();
	}
	
	public Student(String name, Date dob, int pRN, String cource_name, int age) {
		super(name, dob);
		PRN = pRN;
		this.cource_name = cource_name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Student PRN= " + PRN + 
				"cource_name= " + cource_name + 
				"age= " + age;
	}

	public void display() {
		System.out.println("Student PRN= " + PRN + 
				"cource_name= " + cource_name + 
				"age= " + age);
		
	}

}
