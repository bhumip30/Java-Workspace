package Book.utils;

public class PaperBook extends Book {
	private int no_of_pages;
	private Date date_of_publication;
	
	public PaperBook () {
		
	}

	public PaperBook(int bookid, String title, float price, int pages, Date  date_of_publication ) {
		super(bookid, title, price);
		// TODO Auto-generated constructor stub
		this.no_of_pages = pages;
		this.date_of_publication = date_of_publication;
	}
	
	public void display() {
		super.display();
		System.out.println("The book pages: "+ no_of_pages);
		System.out.println("The book date of publication:  "+ date_of_publication);
		
	}
	


	
	

}
