package Book.utils;

public class book_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PaperBook p1 = new PaperBook(1, "Java", 500.00f, 200, new Date(12,12,2003));
		p1.display();
		
		//eBook e1 = new eBook(2, "CPP", 200.0f, "www.cppbook.com", 40);
		//e1.display();
	}

}
